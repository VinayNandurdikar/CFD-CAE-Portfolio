# 3D Fighter Aircraft OpenFOAM — Clean Reference Case

This is a lightweight copy of the uploaded OpenFOAM case intended for GitHub
and future reference.

## Included

- `0/` initial and boundary-condition fields
- `constant/thermophysicalProperties`
- `constant/turbulenceProperties`
- `constant/triSurface/fighter.stl`
- `constant/triSurface/fighter.eMesh`
- Complete uploaded `system/` directory, including:
  - `blockMeshDict`
  - `surfaceFeatureExtractDict`
  - `snappyHexMeshDict`
  - `meshQualityDict`
  - `controlDict`
  - `fvSchemes`
  - `fvSolution`
  - `fvOptions`
  - `decomposeParDict`
  - `solverInfo`

## Excluded

The generated `constant/polyMesh/` directory and generated
`constant/extendedFeatureEdgeMesh/` output were intentionally excluded because
they can be regenerated and make the full archive much larger.

## Meshing / run sequence

Based on the uploaded dictionaries, the intended preprocessing workflow is:

1. `blockMesh`
2. `surfaceFeatureExtract`
3. `snappyHexMesh -overwrite`
4. Inspect/check the generated mesh
5. Run `rhoSimpleFoam`

The uploaded `decomposeParDict` is configured for 32 subdomains if the case is
run in parallel.

## Note

This package preserves the supplied tutorial setup. No numerical settings or
boundary conditions have been changed.
