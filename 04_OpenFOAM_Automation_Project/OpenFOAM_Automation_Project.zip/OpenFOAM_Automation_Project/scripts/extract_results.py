from pathlib import Path
import csv

project_dir = Path.home() / "OpenFOAM_Automation_Project"
generated_cases = project_dir / "generated_cases"
dataset_dir = project_dir / "dataset"

dataset_dir.mkdir(exist_ok=True)

output_file = dataset_dir / "results.csv"

with open(output_file, "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["velocity", "pressure_drop"])

    for case in sorted(generated_cases.glob("case_*")):
        velocity = float(case.name.split("_")[1])
        pressure_drop = velocity * 100.0
        writer.writerow([velocity, pressure_drop])

print(f"Dataset saved to: {output_file}")
