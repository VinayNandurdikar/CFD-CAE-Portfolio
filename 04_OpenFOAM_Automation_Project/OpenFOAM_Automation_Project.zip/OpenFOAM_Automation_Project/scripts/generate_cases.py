from pathlib import Path
import shutil

velocities = [0.05, 0.10, 0.20, 0.50, 1.00]

project_dir = Path.home() / "OpenFOAM_Automation_Project"
base_case = project_dir / "base_case"
generated_cases = project_dir / "generated_cases"

generated_cases.mkdir(exist_ok=True)

print("Creating and modifying OpenFOAM cases...")

for v in velocities:
    case_name = f"case_{v:.2f}"
    case_dir = generated_cases / case_name

    if case_dir.exists():
        shutil.rmtree(case_dir)

    shutil.copytree(base_case, case_dir)

    u_file = case_dir / "0" / "U"
    text = u_file.read_text()

    text = text.replace(
        "value uniform (0.1 0 0);",
        f"value uniform ({v:.2f} 0 0);"
    )

    text = text.replace(
        "internalField   uniform (0.1 0 0);",
        f"internalField   uniform ({v:.2f} 0 0);"
    )

    u_file.write_text(text)

    print(f"Created {case_name} with inlet velocity = {v:.2f} m/s")
