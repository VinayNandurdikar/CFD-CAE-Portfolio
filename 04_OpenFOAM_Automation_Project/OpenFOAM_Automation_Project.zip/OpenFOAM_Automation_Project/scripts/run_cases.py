from pathlib import Path
import subprocess

project_dir = Path.home() / "OpenFOAM_Automation_Project"
generated_cases = project_dir / "generated_cases"

case_folders = sorted(generated_cases.glob("case_*"))

for case in case_folders:
    print(f"\nRunning {case.name} ...")

    # Run blockMesh
    subprocess.run(["blockMesh"], cwd=case)

    # Run simpleFoam
    subprocess.run(["simpleFoam"], cwd=case)

    print(f"Finished {case.name}")
